# SpruhaEmergencyResponseApp
The folder contains the visualization code.
