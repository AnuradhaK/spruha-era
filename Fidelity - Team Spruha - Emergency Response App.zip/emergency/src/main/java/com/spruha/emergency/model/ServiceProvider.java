package com.spruha.emergency.model;

import lombok.Data;

@Data
public class ServiceProvider {
	
	private long spId;
	private String spArea;
	private String spLat;
	private String spLng;
	
}
