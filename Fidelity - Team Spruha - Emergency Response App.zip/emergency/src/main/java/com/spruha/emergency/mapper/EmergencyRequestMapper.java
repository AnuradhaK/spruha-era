package com.spruha.emergency.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.spruha.emergency.model.EmergencyRequest;
import com.spruha.emergency.model.EmergencyResponse;
import com.spruha.emergency.model.ServiceProvider;

@Repository
@Transactional
public interface EmergencyRequestMapper {
	
	@Select("SELECT Request_ID as requestId ,Request_Type as requestType,Request_Catagory as requestCategory, Request_Originated_Time as requestOriginTime, "
			+ " Request_Owner as requestOwner, Request_Owner_contact as requestOwnerContact,Request_latitude as requestOriginLat, Request_longitude as requestOriginLong, "
			+ " Request_Raised_By as raisedBy, Request_Description as requestDesc, Request_Status as requestStatus FROM emergency_requests")
	public List<EmergencyRequest> getEmergencyRequestAll();
	
	@Select("SELECT Request_ID as requestId ,Request_Type as requestType,Request_Catagory as requestCategory, Request_Originated_Time as requestOriginTime, "
			+ " Request_Owner as requestOwner, Request_Owner_contact as requestOwnerContact, Request_latitude as requestOriginLat, Request_longitude as requestOriginLong, "
			+ " Request_Raised_By as raisedBy, Request_Description as requestDesc, Request_Status as requestStatus FROM emergency_requests where Request_Status = 'Open'")
	public List<EmergencyRequest> getEmergencyRequestsOpen();

	@Select("SELECT Request_ID as requestId ,Request_Type as requestType,Request_Catagory as requestCategory, Request_Originated_Time as requestOriginTime, "
			+ " Request_Owner as requestOwner, Request_Owner_contact as requestOwnerContact, Request_Originated_At as requestOrigin ,"
			+ " Request_Raised_By as raisedBy, Request_Description as requestDesc, Request_Status as requestStatus  FROM emergency_requests "
			+ " WHERE REQUEST_ID = #{requestId}")
	public EmergencyRequest getEmergencyRequestById(@Param("requestId") long requestId);
	
	@Select("SELECT REQ.Request_ID as requestId, REQ.Request_Status as requestStatus, REQ.Request_Owner as requestOwner , "
			+ " REQ.Request_Owner_contact as requestOwnerContact, CTL.Current_Latitude as requestOwnerLat, CTL.Current_Longitude as requestOwnerLong  "
			+ " FROM emergency_requests REQ LEFT JOIN services_catalog_local CTL on REQ.Request_ID=CTL.Request_Working_On "
			+ " WHERE REQ.Request_ID = #{requestId}")
	public EmergencyResponse getEmergencyRequestStatus(@Param("requestId") long requestId);
	
	@Insert("INSERT INTO  emergency_requests(Request_Type,Request_Catagory, Request_latitude, Request_longitude, Request_Status) VALUES(#{requestType},#{requestCategory},#{requestOriginLat}, #{requestOriginLong}, 'Open')")
	@Options(useGeneratedKeys=true, keyProperty="requestId", keyColumn="Request_ID")
	public int createEmergencyRequest(EmergencyRequest er);
	
	@Update("update emergency_requests set Request_Owner=#{requestOwner} where Request_ID=#{requestId}")
	public int acceptEmergencyRequest(@Param("requestId") long requestId, @Param("requestOwner") long requestOwner);

	@Update("update services_catalog_local set Request_Working_On=#{requestId} where Volunteer_ID=#{volunteertId}")
	public int assignEmergencyRequest(@Param("requestId") long requestId, @Param("volunteertId") long volunteertId);

	@Update("UPDATE emergency_requests SET Request_Status = 'Closed' WHERE Request_ID = #{requestId} ")
	public int closeEmergencyRequest(@Param("requestId") long requestId);

	@Select("SELECT Service_Provider_ID as spId, Service_Provider_Area as spArea, Service_Provider_Base_Latitude as spLat, Service_Provider_Base_Longitude as spLng FROM services_catalog_master where Service_Provider_Type like 'Local Volunteer Group'")
	public List<ServiceProvider> getCloserServiceProvider();
	
	
	//Select * from services_catalog_master
}
