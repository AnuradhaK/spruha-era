package com.spruha.emergency.exception;

public class InvalidRequestException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 9002620259555867446L;

	public InvalidRequestException(String msg) {
		super(msg);
	}

}
