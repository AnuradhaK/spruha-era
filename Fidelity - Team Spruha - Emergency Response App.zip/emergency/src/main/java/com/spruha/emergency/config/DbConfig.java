package com.spruha.emergency.config;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperFactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.spruha.emergency.mapper.EmergencyRequestMapper;
import com.spruha.emergency.mapper.ServiceProviderMapper;


@Configuration
public class DbConfig {
	
	@Value("${spruhadb.driverClassName}")
	private String driverClassName;
	@Value("${spruhadb.url}")
	private String url;
	
	@Bean
	public MapperFactoryBean<EmergencyRequestMapper> getEmergencyRequestMapperBean() throws Exception {
		MapperFactoryBean<EmergencyRequestMapper> requestMapper = new MapperFactoryBean();
		requestMapper.setMapperInterface(EmergencyRequestMapper.class);
		requestMapper.setSqlSessionFactory(getSqlSessionFactory());
		return requestMapper;	
	}
	
	@Bean
	public MapperFactoryBean<ServiceProviderMapper> getServiceProviderMapperBean() throws Exception {
		MapperFactoryBean<ServiceProviderMapper> requestMapper = new MapperFactoryBean();
		requestMapper.setMapperInterface(ServiceProviderMapper.class);
		requestMapper.setSqlSessionFactory(getSqlSessionFactory());
		return requestMapper;	
	}
	
	@Bean
	public SqlSessionFactory getSqlSessionFactory() throws Exception{
		SqlSessionFactory sf =getSqlSessionFactoryBean().getObject();
		return sf;
	}
	
	@Bean
	public SqlSessionFactoryBean getSqlSessionFactoryBean() {
		SqlSessionFactoryBean sfBean = new SqlSessionFactoryBean();
		sfBean.setDataSource(getSqlDataSource());
		return sfBean;
	}
	
	@Bean(destroyMethod="close") 
	public BasicDataSource getSqlDataSource() {
		BasicDataSource db = new BasicDataSource();
		db.setDriverClassName(driverClassName);
		db.setUrl(url);
		db.setInitialSize(10);
		return db;
		
	}
	
}
