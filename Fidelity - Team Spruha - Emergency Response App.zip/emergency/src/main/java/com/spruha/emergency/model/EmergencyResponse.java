package com.spruha.emergency.model;

import java.math.BigDecimal;

//import lombok.Data;

//@Data
public class EmergencyResponse {
	
	private long requestId;
	private long requestOwner;
	private BigDecimal requestOwnerContact; 
	private String requestOwnerLat;
	private String requestOwnerLong;
	private String requestStatus;
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public long getRequestOwner() {
		return requestOwner;
	}
	public void setRequestOwner(long requestOwner) {
		this.requestOwner = requestOwner;
	}
	public BigDecimal getRequestOwnerContact() {
		return requestOwnerContact;
	}
	public void setRequestOwnerContact(BigDecimal requestOwnerContact) {
		this.requestOwnerContact = requestOwnerContact;
	}
	public String getRequestOwnerLat() {
		return requestOwnerLat;
	}
	public void setRequestOwnerLat(String requestOwnerLat) {
		this.requestOwnerLat = requestOwnerLat;
	}
	public String getRequestOwnerLong() {
		return requestOwnerLong;
	}
	public void setRequestOwnerLong(String requestOwnerLong) {
		this.requestOwnerLong = requestOwnerLong;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	
	
}
