package com.spruha.emergency.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.spruha.emergency.model.ServiceProvider;

@Repository
@Transactional
public interface ServiceProviderMapper {
	

	@Select("SELECT Service_Provider_ID as spId, Service_Provider_Area as spArea, Service_Provider_Base_Latitude as spLat, Service_Provider_Base_Longitude as spLng FROM services_catalog_master where Service_Provider_Type like 'Local Volunteer Group'")
	public List<ServiceProvider> getCloserLocalVolunteers();
	
	
	//Select * from services_catalog_master
}
