package com.spruha.emergency.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class EmergencyRequest {
	
	private long requestId;
	private String requestType;
	private String requestCategory;
	private Timestamp requestOriginTime;
	private long requestOwner;
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getRequestCategory() {
		return requestCategory;
	}
	public void setRequestCategory(String requestCategory) {
		this.requestCategory = requestCategory;
	}
	public Timestamp getRequestOriginTime() {
		return requestOriginTime;
	}
	public void setRequestOriginTime(Timestamp requestOriginTime) {
		this.requestOriginTime = requestOriginTime;
	}
	public long getRequestOwner() {
		return requestOwner;
	}
	public void setRequestOwner(long requestOwner) {
		this.requestOwner = requestOwner;
	}
	public BigDecimal getRequestOwnerContact() {
		return requestOwnerContact;
	}
	public void setRequestOwnerContact(BigDecimal requestOwnerContact) {
		this.requestOwnerContact = requestOwnerContact;
	}
	public String getRequestOriginLat() {
		return requestOriginLat;
	}
	public void setRequestOriginLat(String requestOriginLat) {
		this.requestOriginLat = requestOriginLat;
	}
	public String getRequestOriginLong() {
		return requestOriginLong;
	}
	public void setRequestOriginLong(String requestOriginLong) {
		this.requestOriginLong = requestOriginLong;
	}
	public long getRaisedBy() {
		return raisedBy;
	}
	public void setRaisedBy(long raisedBy) {
		this.raisedBy = raisedBy;
	}
	public String getRequestDesc() {
		return requestDesc;
	}
	public void setRequestDesc(String requestDesc) {
		this.requestDesc = requestDesc;
	}
	public String getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}
	private BigDecimal requestOwnerContact; 
	private String requestOriginLat;
	private String requestOriginLong;
	private long raisedBy;
	private String requestDesc;
	private String requestStatus;
	
}
