package com.spruha.emergency.controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.spruha.emergency.exception.InvalidRequestException;
import com.spruha.emergency.mapper.EmergencyRequestMapper;
import com.spruha.emergency.model.EmergencyRequest;
import com.spruha.emergency.model.EmergencyResponse;
import com.spruha.emergency.model.ServiceProvider;

//import lombok.extern.slf4j.Slf4j;

@RestController
//@Slf4j
public class RequestController {

	@Autowired
	EmergencyRequestMapper requestMapper;
	
	
	@RequestMapping(value="/request/all", method=RequestMethod.GET)
	public List<EmergencyRequest> getEmergencyRequestAll() {
		//log.debug("Inside RequestController");
		try {
			List<EmergencyRequest> er = requestMapper.getEmergencyRequestAll();
		   return er;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return null; 
	}
	
	@RequestMapping(value="/request/id/{requestId}", method=RequestMethod.GET)
	public EmergencyRequest getEmergencyRequestById(@PathVariable(value="requestId", required = true) long requestId){
		try {
		   EmergencyRequest er = requestMapper.getEmergencyRequestById(requestId);
		   return er;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	@CrossOrigin
	@RequestMapping(value="/request/open", method=RequestMethod.POST)
	public @ResponseBody ResponseEntity<String> createEmergencyRequestById(//@PathVariable(value="userId", required = false) final String userId,
			 @RequestBody final Map<String, String> requestModel) throws InvalidRequestException {
		
	
		try {
			//log.debug("Inside RequestController- /request/new");
			
			final String latitude = requestModel.getOrDefault("lat", "");
			final String longitude = requestModel.getOrDefault("lng", "");
			
			EmergencyRequest er = new EmergencyRequest();
			er.setRequestOriginLat(latitude);
			er.setRequestOriginLong(longitude);
			er.setRequestType(requestModel.getOrDefault("type", "Self"));
			er.setRequestCategory(requestModel.getOrDefault("category", "Accident"));
			requestMapper.createEmergencyRequest(er);
			
			List<ServiceProvider> sp = requestMapper.getCloserServiceProvider();
			
			ObjectMapper objMapper = new ObjectMapper();
			ArrayNode volunteerArray = objMapper.valueToTree(sp);
			//ObjectNode requestNode = objMapper.valueToTree(er);
			ObjectNode requestNode = objMapper.createObjectNode();
			requestNode.put("requestId", er.getRequestId());
			requestNode.putArray("volunteers").addAll(volunteerArray);
			JsonNode result = objMapper.createObjectNode().set("request", requestNode);
		//	log.debug("Inside RequestController- /request/new created"+er.getRequestId());
		
		return new ResponseEntity<String>(result.toString(),HttpStatus.OK);
		
		}
		catch(Exception e) {
			//e.printStackTrace();
		//	log.debug(e.getLocalizedMessage());
			return new ResponseEntity<String>("{}",HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
	
	}
	
	@CrossOrigin
	@RequestMapping(value="/request/accept/{requestId}", method=RequestMethod.POST)
	public @ResponseBody ResponseEntity<String> acceptEmergencyRequest(@PathVariable(value="requestId", required = true) final String requestId,
			 @RequestBody final Map<String, String> requestModel) throws InvalidRequestException {
		
		try {
			long requestIdL= Long.valueOf(requestId);
			long requestOwnerL= Long.valueOf(requestModel.getOrDefault("requestOwner", "1000"));
		  int status = requestMapper.acceptEmergencyRequest(requestIdL, requestOwnerL);
		  return new ResponseEntity<String>("{status : SUCCESS }",HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<String>("{}",HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
	}
	
	@CrossOrigin
	@RequestMapping(value="/request/assign/{requestId}", method=RequestMethod.POST)
	public @ResponseBody ResponseEntity<String> assigntEmergencyRequest(@PathVariable(value="requestId", required = true) final String requestId,
			 @RequestBody final Map<String, String> requestModel) throws InvalidRequestException {
		
		try {
			long requestIdL= Long.valueOf(requestId);
			long volunteertIdL =  Long.valueOf(requestModel.getOrDefault("volunteerId", "30000"));
			 int status = requestMapper.assignEmergencyRequest(requestIdL, volunteertIdL);
			  
		  return new ResponseEntity<String>("{status : SUCCESS }",HttpStatus.OK);
		}
		catch(Exception e) {
			return new ResponseEntity<String>("{}",HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
	}
	
	@CrossOrigin
	@RequestMapping(value="/request/status/{requestId}", method=RequestMethod.GET)
	public @ResponseBody ResponseEntity<String> getEmergencyRequestStatus(@PathVariable(value="requestId", required = true) final String requestId){
		
		try {
			long requestIdL= Long.valueOf(requestId);
		EmergencyResponse  status = requestMapper.getEmergencyRequestStatus(requestIdL);
		ObjectMapper objMapper = new ObjectMapper();
		String jsonResult = objMapper.writeValueAsString(status);
		return new ResponseEntity<String>(jsonResult.toString(),HttpStatus.OK);
		}
		catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("{}",HttpStatus.INTERNAL_SERVER_ERROR) ;
		}
	}
	
	@RequestMapping(value="/request/{requestId}/close", method=RequestMethod.POST)
	@ResponseStatus(code=HttpStatus.OK)
	public @ResponseBody ResponseEntity<String>  closeEmergencyRequestById(@PathVariable(value="requestId", required = true) long requestId) throws InvalidRequestException {
		try {
			
		int er = requestMapper.closeEmergencyRequest(requestId);
		return new ResponseEntity<String>(HttpStatus.OK);
		}
		catch(Exception e) {
			
		}
		throw new InvalidRequestException("Error");
		
		
	}
}
