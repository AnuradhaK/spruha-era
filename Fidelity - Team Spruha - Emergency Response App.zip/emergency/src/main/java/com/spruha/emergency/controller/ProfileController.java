package com.spruha.emergency.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.spruha.emergency.model.ProfileInfo;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class ProfileController {

	
	
	
	@RequestMapping(value="{userId}", method=RequestMethod.GET)
	public ProfileInfo getEmergencyRequestAll(@PathVariable final long userId) {
		
		ProfileInfo profileId = new ProfileInfo();
		try {
			//log.trace("Inside getEmergencyRequestAll");
		
		   return profileId;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return null;
	}
	
	
}
