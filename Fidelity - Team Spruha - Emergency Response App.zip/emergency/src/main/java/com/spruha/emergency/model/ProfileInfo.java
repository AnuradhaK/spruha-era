package com.spruha.emergency.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

import lombok.Data;

@Data
public class ProfileInfo {
	
	private long requestId;
	private String requestType;
	private String requestCategory;
	private Timestamp requestOriginTime;
	private long requestOwner;
	private BigDecimal requestOwnerContact; 
	private String requestOrigin;
	private long raisedBy;
	private String requestDesc;
	private String requestStatus;
	
}
