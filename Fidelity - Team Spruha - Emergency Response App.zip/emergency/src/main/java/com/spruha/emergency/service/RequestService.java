package com.spruha.emergency.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.spruha.emergency.mapper.EmergencyRequestMapper;

public class RequestService {
	
	@Autowired
	EmergencyRequestMapper requestMapper;
	
	
	
}
