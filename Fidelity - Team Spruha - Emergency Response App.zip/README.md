# SpruhaEmergencyResponseApp
This project is the poc implementation of an Emergency Response application. The users of this application are members of informal response teams. Please see deck for a description of business problem.
